package labmock;

public interface IServicoEmail {

	public boolean sendEmail(String email, String message) ;
}
