package labmock;

public interface IValidatorProcesso {
	
	public boolean validaProcesso(IProcesso proc);

}
